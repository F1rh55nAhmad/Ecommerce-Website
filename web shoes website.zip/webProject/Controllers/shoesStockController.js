const db = require("../model");
const ShoeStock = db.shoesStock;
const Op = db.Sequelize.Op;

exports.create = (req, res) => {
  // Validate request
  if (!req.body.ArticleNo) {
    res.status(400).send({
      message: "Content can not be empty!",
    });
    return;
  }

  const shoesStock = {
    ArticleNo: req.body.ArticleNo,
    Size: req.body.Size,
    Qunatity:req.body.Qunatity,
    Type:req.body.Type,
    Price:req.body.Price
  };

  ShoeStock.create(shoesStock)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Feedback.",
      });
    });
};

// Retrieve all Feedback from the database.
exports.findAll = (req, res) => {
  offset = 5*(req.query.page == undefined ?0: req.query.page-1)
  ShoeStock.findAll({offset:offset,limit:5})
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Feedback.",
      });
    });
};

// Find a single Feedback with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  shoesStock.findByPk(id)
    .then((data) => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `Cannot find ShoesStock with id=${id}.`,
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error retrieving ShoesStock with id=" + id,
      });
    });
};

// Update a Feedback by the id in the request
exports.update = (req, res) => {
  const id = req.params.id;

  shoesStock.update(req.body, {
    where: { id: id },
  })
    .then((num) => {
      if (num == 1) {
        res.send({
          message: "Feedback was updated successfully.",
        });
      } else {
        res.send({
          message: `Cannot update Feedback with id=${id}. Maybe Feedback was not found or req.body is empty!`,
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error updating Feedback with id=" + id,
      });
    });
};

// Delete a Feedback with the specified id in the request
exports.delete = (req, res) => {
  const id = req.params.id;

  shoesStock.destroy({
    where: { id: id },
  })
    .then((num) => {
      if (num == 1) {
        res.send({
          message: "Feedback was deleted successfully!",
        });
      } else {
        res.send({
          message: `Cannot delete Feedback with id=${id}. Maybe Feedback was not found!`,
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Could not delete Feedback with id=" + id,
      });
    });
};

// Delete all Feedbacks from the database.
exports.deleteAll = (req, res) => {
    shoesStock.destroy({
    where: {},
    truncate: false,
  })
    .then((nums) => {
      res.send({ message: `${nums} Feedback were deleted successfully!` });
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all Feedbacks.",
      });
    });
};


