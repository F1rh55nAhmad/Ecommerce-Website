module.exports = (sequelize, DataTypes) => {

    const Order = sequelize.define("order", {
     
        ArticleNo: {
            type : DataTypes.INTEGER
        },
        Size: {
            type : DataTypes.STRING
        },
        Qunatity: {
            type : DataTypes.INTEGER
        },
        Price: {
            type : DataTypes.INTEGER
        }
    
    })

    return Order

}