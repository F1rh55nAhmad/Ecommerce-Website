module.exports = (sequelize, DataTypes) => {

    const Customer = sequelize.define("customer", {
        Phone: {
            type : DataTypes.INTEGER
        },
        Address: {
            type : DataTypes.STRING
        },
        Mail: {
            type : DataTypes.STRING
        }
    
    })

    return Customer

}