module.exports = (sequelize, DataTypes) => {

    const Feedback = sequelize.define("feedback", {
       
        comments: {
            type : DataTypes.STRING
        }
    
    })

    return Feedback

}