module.exports = (sequelize, DataTypes) => {

    const shoesStock = sequelize.define("shoesStock", {
     
        ArticleNo: {
            type : DataTypes.INTEGER
        },
        Size: {
            type : DataTypes.INTEGER
        },
        Qunatity: {
            type : DataTypes.INTEGER
        },
        Type: {
            type : DataTypes.STRING
        },
        Price: {
            type : DataTypes.INTEGER
        }

    
    })

    return shoesStock

}