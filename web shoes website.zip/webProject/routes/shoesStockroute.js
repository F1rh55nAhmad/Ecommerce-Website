const express = require('express');
const router = express.Router();
const shoesStock = require('../Controllers/shoesStockController.js');

// CREATE registered user
router.post('/', (req,res) => {
    console.log("adsas");
    shoesStock.create(req,res)});

// READ registered user by id
router.get('/:id', () => {shoesStock.findOne});

// READ ALL registered users
router.get('/', (req,res) => {shoesStock.findAll(req,res)});

// UPDATE registered user by id
router.put('/:id',() => {shoesStock.update});

// DELETE registered user by id
router.delete('/:id', () => {shoesStock.delete});

// DELETE ALL registered users
router.delete('/', () => {shoesStock.deleteAll});

module.exports = router;
