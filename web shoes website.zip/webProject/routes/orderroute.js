const express = require('express');
const router = express.Router();
const orders = require('../Controllers/feedbackController');

// CREATE registered user
router.post('/', (req,res) => {
    orders.create(req,res)});

// READ registered user by id
router.get('/:id', () => {orders.findOne});

// READ ALL registered users
router.get('/', () => {orders.findAll});

// UPDATE registered user by id
router.put('/:id',() => {orders.update});

// DELETE registered user by id
router.delete('/:id', () => {orders.delete});

// DELETE ALL registered users
router.delete('/', () => {orders.deleteAll});

module.exports = router;
