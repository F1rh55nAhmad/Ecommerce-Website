const express = require('express');
const router = express.Router();
const customers = require('../Controllers/feedbackController');

// CREATE registered user
router.post('/', (req,res) => {
    customers.create(req,res)});

// READ registered user by id
router.get('/:id', () => {customers.findOne});

// READ ALL registered users
router.get('/', () => {customers.findAll});

// UPDATE registered user by id
router.put('/:id',() => {customers.update});

// DELETE registered user by id
router.delete('/:id', () => {customers.delete});

// DELETE ALL registered users
router.delete('/', () => {customers.deleteAll});

module.exports = router;
