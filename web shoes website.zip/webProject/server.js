const express = require('express')
const cors = require('cors')

const feedbackRoute = require('./routes/feedbackRoute');
const orderroute = require('./routes/orderroute');
const customerroute = require('./routes/customerroute');
const shoesStockroute = require('./routes/shoesStockroute.js');

const app = express()
// Register the registered routes
app.use(express.json())

app.use('/feedback', feedbackRoute);
app.use('/order', orderroute);
app.use('/customer', customerroute);
app.use('/shoesStock', shoesStockroute);

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});





