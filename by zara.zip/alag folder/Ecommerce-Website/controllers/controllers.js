const projectname = (req , res ) => { res.send("Welcome to Web Project") }



module.exports = {
    projectname
  
//first try 
}
